
module.exports = {
  secret: 'jwt_secret'
}
